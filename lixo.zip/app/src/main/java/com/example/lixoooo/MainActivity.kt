
package com.example.lixoooo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lixoooo.databinding.ActivityMainBinding
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebViewClient
import android.graphics.Bitmap
import android.widget.Toast


public class MainActivity : AppCompatActivity() {

    private var _binding: ActivityMainBinding? = null
    
    private val binding: ActivityMainBinding
      get() = checkNotNull(_binding) { "Activity has been destroyed" }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate and get instance of binding
        _binding = ActivityMainBinding.inflate(layoutInflater)

        // set content view to binding's root
        setContentView(binding.root)
        
        // Definir o User-Agent 
        val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36" 
        binding.webview1.settings.userAgentString = userAgent 
        //javascript
        val webSettings: WebSettings = binding.webview1.settings
        webSettings.javaScriptEnabled = true
        
        binding.webview1.webViewClient = MyWebViewClient() // Define o WebViewClient personalizado
        
        
        val myAsyncTask = MyAsyncTask(binding.webview1)
         myAsyncTask.execute()


        // Carregar a URL do YouTube 
        binding.webview1.loadUrl("https://web.whatsapp.com/")
         
        //seila
        binding.webview1.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            val totalHeight = binding.webview1.contentHeight * binding.webview1.scaleY
            val currentHeight = binding.webview1.height + scrollY
            val percentageScrolled = currentHeight / totalHeight

            // Se o usuário estiver rolando para baixo e atingir uma porcentagem específica da página
            if (percentageScrolled >= 0.8) {
                // Carregar mais conteúdo dinamicamente
                loadMoreContent()
            }
        }
    }

    private fun loadMoreContent() {
        // Implemente a lógica para carregar mais conteúdo aqui
        // Por exemplo, você pode usar o método loadUrl() para carregar uma parte adicional da página
        
    }
    
    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
