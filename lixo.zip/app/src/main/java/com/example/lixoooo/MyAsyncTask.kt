package com.example.lixoooo;

import android.os.AsyncTask
import android.webkit.WebView

class MyAsyncTask(private val webView: WebView) : AsyncTask<Void, Void, String>() {

    // Este método é executado em uma thread em segundo plano
    override fun doInBackground(vararg params: Void?): String {
        // Simula um trabalho em segundo plano, como acessar uma API ou banco de dados
        Thread.sleep(3000) // Simula um trabalho de 3 segundos
        return "Resultado do trabalho em segundo plano"
    }

    // Este método é executado na thread principal após o término do trabalho em segundo plano
    override fun onPostExecute(result: String) {
        super.onPostExecute(result)
        // Atualiza o WebView com o resultado do trabalho em segundo plano
        // Por exemplo, carregue uma nova URL no WebView
        // webView.loadUrl("https://www.example.com")
    }
}
