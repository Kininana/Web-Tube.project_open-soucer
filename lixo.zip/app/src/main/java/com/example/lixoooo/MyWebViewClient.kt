package com.example.lixoooo;

import android.graphics.Bitmap
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MyWebViewClient : WebViewClient() {
    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        // Método chamado quando a página começa a ser carregada
        super.onPageStarted(view, url, favicon)
         
        // Pré-carregar recursos críticos
        view?.loadUrl("javascript:(function() {" +
                "var links = document.getElementsByTagName('link');" +
                "for (var i = 0; i < links.length; i++) {" +
                "    if (links[i].rel === 'stylesheet') {" +
                "        var href = links[i].getAttribute('href');" +
                "        var preloadLink = document.createElement('link');" +
                "        preloadLink.rel = 'preload';" +
                "        preloadLink.as = 'style';" +
                "        preloadLink.href = href;" +
                "        document.head.appendChild(preloadLink);" +
                "    }" +
                "}" +
                "var scripts = document.getElementsByTagName('script');" +
                "for (var i = 0; i < scripts.length; i++) {" +
                "    var src = scripts[i].getAttribute('src');" +
                "    if (src) {" +
                "        var preloadScript = document.createElement('link');" +
                "        preloadScript.rel = 'preload';" +
                "        preloadScript.as = 'script';" +
                "        preloadScript.href = src;" +
                "        document.head.appendChild(preloadScript);" +
                "    }" +
                "}" +
                "var images = document.getElementsByTagName('img');" +
                "for (var i = 0; i < images.length; i++) {" +
                "    var src = images[i].getAttribute('src');" +
                "    if (src) {" +
                "        var preloadImg = document.createElement('link');" +
                "        preloadImg.rel = 'preload';" +
                "        preloadImg.as = 'image';" +
                "        preloadImg.href = src;" +
                "        document.head.appendChild(preloadImg);" +
                "    }" +
                "}" +
                "})()")
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        // Método chamado quando a página termina de carregar
        super.onPageFinished(view, url)
    }

    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
        // Método chamado quando ocorre um erro de carregamento da página
        super.onReceivedError(view, request, error)

        // Exibir mensagem de erro
        val description = error?.description ?: "Unknown error"
        Toast.makeText(view?.context, "Erro ao carregar a página: $description", Toast.LENGTH_SHORT).show()
    }
}

